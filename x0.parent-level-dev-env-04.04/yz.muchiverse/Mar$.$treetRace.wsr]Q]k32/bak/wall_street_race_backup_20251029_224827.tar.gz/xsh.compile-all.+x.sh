#!/bin/bash

# Create the main +x/ directory if it doesn't exist
main_output_dir="+x"
if [ ! -d "$main_output_dir" ]; then
    mkdir "$main_output_dir"
    if [ $? -ne 0 ]; then
        echo "Error: Could not create directory $main_output_dir"
        exit 1
    fi
fi

# Use find to locate all .c files in current directory and subdirectories
find . -name "*.c" -type f | while read -r file; do
    # Get the directory containing the file
    file_dir=$(dirname "$file")
    # Get the filename without path
    filename=$(basename "$file")
    # Get the base name without extension
    basename="${filename%.c}"
    
    # Create +x directory in the same location as the .c file
    output_dir="$file_dir/+x"
    if [ ! -d "$output_dir" ]; then
        mkdir -p "$output_dir"
        if [ $? -ne 0 ]; then
            echo "Error: Could not create directory $output_dir"
            continue
        fi
    fi
    
    # Define the executable name
    executable_name="${basename}.+x"
    
    # Check if we're on macOS or Linux and compile accordingly
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS compilation with frameworks
        # Note: Removed -lOpenCL as it's not always available on macOS
        gcc -D_DARWIN_C_SOURCE "$file" -o "$output_dir/$executable_name" -framework OpenGL -framework GLUT -lm -lssl -lcrypto -lfreetype -lavcodec -lavformat -lavutil -lswscale -lassimp -I/usr/include/freetype2 -I/usr/include/libpng12 -L/usr/local/lib
    else
        # Linux compilation (original command)
        gcc "$file" -o "$output_dir/$executable_name" -pthread -lm -lssl -lcrypto -lGL -lGLU -lglut -lGLEW -lfreetype -lavcodec -lavformat -lavutil -lswscale -lX11 -lassimp -I/usr/include/freetype2 -I/usr/include/libpng12 -L/usr/local/lib -lOpenCL
    fi

    # Check the exit status of gcc
    if [ $? -eq 0 ]; then
        echo "Successfully compiled $file into $output_dir/$executable_name"
    else
        echo "Error compiling $file"
    fi
done

echo "Compilation complete."